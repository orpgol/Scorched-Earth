﻿using UnityEngine;
using System.Collections;

public class SC_Enemy : MonoBehaviour 
{
	public GameObject bullet;
	public GameObject bulletPos;
	public GameObject shockWave;
	public GameObject death;
	public int shotPower;
	public int shotAngle;
	public int damageTaken;
	private SC_GameLogic sc_GameLogic;
	private bool delayed = false;
	
	// Use this for initialization
	void Start () 
	{
		shotPower = 5000;
		shotAngle = 1000;
		damageTaken = 0;

		if (sc_GameLogic == null)
			sc_GameLogic = GameObject.Find("GameLogic").GetComponent<SC_GameLogic> ();
		rigidbody.AddForce(-Vector3.up * 100);	
	}
	
	// Update is called once per frame
	void Update () 
	{
		if(!sc_GameLogic.isMyTurn)
		{
			if (!delayed) 
			{
				shotPower += 800;
				shotAngle += 200;
				
				//first way to instantiate
				GameObject clone = (GameObject) Instantiate(bullet, transform.position, transform.rotation);
				clone.transform.position = new Vector3(bulletPos.transform.position.x, bulletPos.transform.position.y, bulletPos.transform.position.z);
				if (this.transform.rotation.eulerAngles.y == 0)
					clone.rigidbody.AddForce(shotPower,shotAngle,0);
				else
					clone.rigidbody.AddForce(-shotPower,shotAngle,0);

				StartCoroutine(endTurn(3));

				StartCoroutine(shot(clone));
				
				//second way to instantiate
				StartCoroutine(wave(1.5f));

				delayed = true;
			}

		}
		
	}
	
	public IEnumerator shot(GameObject obj)
	{
		yield return new WaitForSeconds(9);
		Destroy(obj);
	}
	
	public IEnumerator wave(float _timeToWait)
	{
		GameObject _wave = (GameObject) Instantiate (shockWave, bulletPos.transform.position, bulletPos.transform.rotation);
		Debug.Log(bulletPos.transform.position);
		yield return new WaitForSeconds(_timeToWait);
		Destroy(_wave);
	}

	public IEnumerator destruct(float _timeToWait)
	{
		GameObject _des = (GameObject) Instantiate (death, this.transform.position, this.transform.rotation);
		yield return new WaitForSeconds(_timeToWait);
		Destroy(_des);
	}

	public IEnumerator endTurn(float _timeToWait)
	{
		StartCoroutine(sc_GameLogic.OnMoveCompleted(_timeToWait));
		yield return new WaitForSeconds(_timeToWait);
		delayed = false;
	}
	
	public void takeDamage(int amount)
	{
		Debug.Log(this.name + " Took damage: " + amount);
		damageTaken += amount;
		if(damageTaken >= 100)
		{
			StartCoroutine(destruct(3));
			Destroy(this.gameObject);
			sc_GameLogic.gameOver();
		}
	}
	
}
