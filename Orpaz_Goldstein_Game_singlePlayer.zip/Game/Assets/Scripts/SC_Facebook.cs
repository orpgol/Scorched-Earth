﻿using UnityEngine;
using System.Collections;
using Facebook.MiniJSON;
using System.Collections.Generic;

public class SC_Facebook : MonoBehaviour {

	public string fbUserName = "";

	// Use this for initialization
	void Start () 
	{
		FB.Init(setInit);
	}
	
	// Update is called once per frame
	void Update () 
	{
		
	}

	void setInit()
	{

	}

	void onHideUnity()
	{

	}

	public void AuthCallback(FBResult result)
	{
		if (FB.IsLoggedIn)
		{
			Debug.Log("Logged in to facebook");
			FB.API("me", Facebook.HttpMethod.GET, MeGraphCallBack);

		}
	}

	public void MeGraphCallBack(FBResult _res)
	{
		Debug.Log(_res.Text);

		var _dict = Json.Deserialize(_res.Text) as Dictionary<string, object>;
		fbUserName = _dict ["name"].ToString();
	}
}
