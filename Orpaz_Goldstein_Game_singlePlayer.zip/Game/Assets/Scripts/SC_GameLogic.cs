﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using com.shephertz.app42.gaming.multiplayer.client.events;

public class SC_GameLogic : MonoBehaviour
{
//	[HideInInspector]
//	public bool isGameStarted = false;
	[HideInInspector]
	public bool isMyTurn = false;
	public int windFactor;
	public GameObject endGraphic;

	void OnEnable()
	{
		//SC_Listener_AppWarp.OnMoveCompleted += OnMoveCompleted;
	}

	void OnDisable()
	{
		//SC_Listener_AppWarp.OnMoveCompleted -= OnMoveCompleted;
	}

	void Awake()
	{

	}

	void Start () 
	{
	}
	
	void Update () 
	{
	
	}

	public void Init()
	{

	}

//	public void UpdateState(int _Index,State _StateToUpdate)
//	{
//		SC_Menu.sc_AppWarpKit.sendMove (_isWon.ToString());
//	}
	

	public IEnumerator OnMoveCompleted(float _timeToWait)
	{     
		yield return new WaitForSeconds(_timeToWait);
		//isGameStarted = true;
		if(isMyTurn == false)
			isMyTurn = true;

		else isMyTurn = false;

		windFactor = Random.Range(-100, 100);
		Debug.Log ("wind " + windFactor);

		Debug.Log ("isMyTurn " + isMyTurn);
	}

	public void gameOver()
	{
		Debug.Log("Game Over!");

		StartCoroutine(endGame(8));
	}

	public IEnumerator endGame(float _timeToWait)
	{
		yield return new WaitForSeconds(3);
		GameObject _end = (GameObject) Instantiate (endGraphic, this.transform.position, this.transform.rotation);
		yield return new WaitForSeconds(_timeToWait);
		Destroy(_end);
		Application.LoadLevel ("Game_Scene");
	}

}






















