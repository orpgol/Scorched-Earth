namespace NativeDialogModes
{
#if !__cplusplus    
    public
#endif

    enum eModes {
      WEBVIEW_DIALOG_MODE = 0,
      FAST_APP_SWITCH_SHARE_DIALOG,
    };

}
